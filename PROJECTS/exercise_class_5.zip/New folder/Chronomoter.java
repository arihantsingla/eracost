class Chronometer {
    private int hour;
    private int minute;
    private double second;
    
    void Chronometer(int h, int m, double s){
    	hour=h;
    	minute=m;
    	second=s;
    }

    void Chronometer(){
    	hour=0;
    	minute=0;
    	second=0;
    }

    int getHour(){
    	return hour;
    }

    int getMinute(){
    	return minute;
    }

    double getSecond(){
    	return second;
    }

    void setMinute(int m){
    	minute=m;
    }

    void setHour(int h){
    	hour=h;
    }

    void setSecond(double s){
    	second=s;
    }
}