class ChessBoard{

	private int height, width;
	private ChessPiece[][] board;

	public ChessPiece pawn, king, queen, bishop, knight, rook;

	void ChessBoard(int w, int h){
		width=w;
		height=h;
		board = new ChessPiece[h][w];
	}

	void setHeight(int height){
		this.height = height;
	}

	void setWidth(int width){
		this.width = width;
	}

	void setBoard(ChessPiece[][] board){
		this.board= board;
	}

	int getWidth(){
		return width;
	}

	int getHeight(){
		return height;
	}

	ChessPiece[][] getBoard(){
		return board;
	}
}


class ChessPiece{
	String name;
	int posX,posY;
}